<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerTransactions extends Model
{
    use HasFactory;
    protected $guarded = [];
    protected $primaryKey = 'cust_trans_id';

    public function customer(){
      return $this->belongsTo(Customer::class);
    }

}
