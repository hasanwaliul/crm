
<?php $__env->startSection('customer'); ?> active mm-active <?php $__env->stopSection(); ?>
<?php $__env->startSection('customerTransaction'); ?> active <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
  <style media="screen">
    .form-check-label{
      cursor: pointer;
    }
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  
  <div class="row">
      <div class="col-12">
          <div class="page-title-box d-flex align-items-center justify-content-between">
              <h4 class="mb-0 font-size-18">Customer Payment</h4>
              <div class="page-title-right">
                  <ol class="breadcrumb m-0">
                      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                      <li class="breadcrumb-item active">Customer Payment</li>
                  </ol>
              </div>
          </div>
      </div>
  </div>
  
  <div class="row">
      <div class="col-md-2"></div>
      <div class="col-md-8">
          <?php if(Session::has('success_store')): ?>
            <div class="alert alert-success alertsuccess" role="alert">
               <strong>Successfully!</strong> Customer Transaction Done.
            </div>
          <?php endif; ?>


          <?php if(Session::has('due_amount_0')): ?>
            <div class="alert alert-success alertsuccess" role="alert">
               <strong>Opps!</strong> Your arrears have already been paid.
            </div>
          <?php endif; ?>

          <?php if(Session::has('error')): ?>
            <div class="alert alert-warning alerterror" role="alert">
               <strong>Opps!</strong> please try again.
            </div>
          <?php endif; ?>
      </div>
      <div class="col-md-2"></div>
  </div>
  
  <div class="row">
    <div class="col-lg-12">
        <form class="form-horizontal" method="post" action="<?php echo e(route('customer-payment-process',$transaction->cust_trans_id)); ?>" id="customerForm">
          <?php echo csrf_field(); ?>
          <div class="card">
            <div class="card-header custom-card-header">
            </div>

            <div class="card-body card_form">
                <div class="row">
                  <div class="form-group custom_form_group col-md-2">
                      <label class="control-label">Full Contact: <strong><?php echo e($transaction->full_contact); ?></strong> </label>
                  </div>
                  <div class="form-group custom_form_group col-md-2">
                      <label class="control-label">Total Payment: <strong id="payment_amount"><?php echo e($transaction->total_pay); ?></strong> </label>
                      <input type="hidden" name="payment_amount_input" value="<?php echo e($transaction->total_pay); ?>">
                  </div>
                  <div class="form-group custom_form_group col-md-2">
                      <label class="control-label">Total Due: <strong id="due_amount"><?php echo e($transaction->due_to_admin); ?></strong> </label>
                      <input type="hidden" name="due_amount_input" value="<?php echo e($transaction->due_to_admin); ?>">
                  </div>

                </div>
                <div class="row">
                  <div class="form-group custom_form_group col-md-6 m-auto">
                      <label class="control-label">Payment:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="Amount..." class="form-control" name="total_pay" value="<?php echo e(old('total_pay')); ?>" required data-parsley-pattern="[0-9]+$" min="0" data-parsley-length="[1,50]" data-parsley-trigger="keyup" onkeyup="payment()">
                          <?php $__errorArgs = ['total_pay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group custom_form_group col-md-6 m-auto">
                      <label class="control-label">Remarks:</label>
                      <div class="">
                          <textarea name="remarks" class="form-control" placeholder="Remarks..." data-parsley-pattern="[a-zA-Z-_ ]+$" data-parsley-length="[1,220]" data-parsley-trigger="keyup"></textarea>
                          <?php $__errorArgs = ['remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>
            </div>

              <div class="card-footer card_footer_button text-center">
                  <button type="submit" class="btn btn-primary waves-effect">Payment</button>
              </div>
          </div>
          
        </form>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
      /* ================ do work ================ */
      $(document).ready(function() {
          $('#customerForm').parsley();
      });
      /* ================ do work ================ */
    </script>
    
    <script type="text/javascript">
      /* ================ do work ================ */
      function payment(){
        var due_amountshow = parseFloat( $('#due_amount').text() );

        var due_amount_input = parseFloat( $('input[name="due_amount_input"]').val() );

        var payment_amount_input = parseFloat( $('input[name="payment_amount_input"]').val() );

        var total_pay = parseFloat( $('input[name="total_pay"]').val() );

        if(total_pay >= 0 ){
          var due = (due_amount_input - total_pay);
          var payment = (payment_amount_input + total_pay);
          $('#due_amount').text('');
          $('#due_amount').text(due);

          $('#payment_amount').text('');
          $('#payment_amount').text(payment);
        }else{
          $('#due_amount').text('');
          $('#due_amount').text(due_amount_input);

          $('#payment_amount').text('');
          $('#payment_amount').text(payment_amount_input);
        }

      }
      /* ================ do work ================ */
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etcvalyc/Creative.etcvaly.com/resources/views/admin/customer_transaction/payment/index.blade.php ENDPATH**/ ?>