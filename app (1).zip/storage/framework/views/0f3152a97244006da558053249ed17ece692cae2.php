
<?php $__env->startSection('customer'); ?> active mm-active <?php $__env->stopSection(); ?>
<?php $__env->startSection('customerTransaction'); ?> active <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
  <style media="screen">
    .form-check-label{
      cursor: pointer;
    }
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  
  <div class="row">
      <div class="col-12">
          <div class="page-title-box d-flex align-items-center justify-content-between">
              <h4 class="mb-0 font-size-18">Customer Transaction</h4>
              <div class="page-title-right">
                  <ol class="breadcrumb m-0">
                      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                      <li class="breadcrumb-item active">Customer Transaction</li>
                  </ol>
              </div>
          </div>
      </div>
  </div>
  
  <div class="row">
      <div class="col-md-2"></div>
      <div class="col-md-8">
          <?php if(Session::has('success_store_first_step')): ?>
            <div class="alert alert-success alertsuccess" role="alert">
               <strong>Successfully!</strong> Done First Step.
            </div>
          <?php endif; ?>

          <?php if(Session::has('success_save_change')): ?>
            <div class="alert alert-success alertsuccess" role="alert">
               <strong>Successfully!</strong> Save & Change Customer Transaction.
            </div>
          <?php endif; ?>

          <?php if(Session::has('error')): ?>
            <div class="alert alert-warning alerterror" role="alert">
               <strong>Opps!</strong> please try again.
            </div>
          <?php endif; ?>
      </div>
      <div class="col-md-2"></div>
  </div>
  
  <div class="row">
    <div class="col-lg-12">
        <form class="form-horizontal" method="post" action="<?php echo e(route('customer-trnasaction.update',$data->cust_trans_id)); ?>" enctype="multipart/form-data" id="customerForm">
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
          <div class="card">
            <div class="card-header custom-card-header">
                <div class="row">
                    <div class="col-md-8">
                        <h3 class="card-title card_top_title"><i class="fab fa-gg-circle"></i> Customer Transaction</h3>
                    </div>
                    <div class="col-md-4 text-right">
                        <a href="<?php echo e(route('customer-trnasaction.index')); ?>" class="btn btn-md btn-primary waves-effect card_top_button"><i class="fa fa-th"></i> Customer Transaction List </a>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>

            <div class="card-body card_form">
                <div class="row">
                  <div class="form-group custom_form_group col-md-6 m-auto">
                      <label class="control-label">Full Contact:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="Amount..." class="form-control" onkeyup="fullContact()" name="full_contact" value="<?php echo e($data->full_contact); ?>" required data-parsley-pattern="[0-9]+$" min="0" data-parsley-length="[1,50]" data-parsley-trigger="keyup">
                          <?php $__errorArgs = ['full_contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>

                <div class="row">
                  <div class="form-group custom_form_group col-md-6 m-auto">
                      <label class="control-label">Officer Commission:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="Amount..." class="form-control" onkeyup="officerCommision()" name="officer_commision" value="<?php echo e($data->officer_commision); ?>" required data-parsley-pattern="[0-9]+$" min="0" data-parsley-length="[1,50]" data-parsley-trigger="keyup">
                          <?php $__errorArgs = ['officer_commision'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                      </div>
                  </div>
                </div>

                <div class="row">
                  <div class="form-group custom_form_group col-md-6 m-auto">
                      <label class="control-label">Agent Commission:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="Amount..." onkeyup="agentCommision()" class="form-control" id="agent_commision" name="agent_commision" value="<?php echo e($data->agent_commision); ?>" required data-parsley-pattern="[0-9]+$" min="0" data-parsley-length="[1,50]" data-parsley-trigger="keyup">
                          <?php $__errorArgs = ['agent_commision'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group custom_form_group col-md-6 m-auto">
                      <label class="control-label">Total Costing:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="Amount..." class="form-control" id="cost" name="cost" value="<?php echo e($data->cost); ?>" required data-parsley-pattern="[0-9]+$" min="0" data-parsley-length="[1,50]" data-parsley-trigger="keyup">
                          <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          <input type="hidden" id="temporaryOfficerComision" value="">
                      </div>
                  </div>
                </div>

                <div class="row">
                  <div class="form-group custom_form_group col-md-6 m-auto">
                      <label class="control-label">Payment To Admin:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="Amount..." onkeyup="paymentToAdmin()" class="form-control" name="payment_to_admin" value="<?php echo e($data->payment_to_admin); ?>" required data-parsley-pattern="[0-9]+$" min="0" data-parsley-length="[1,50]" data-parsley-trigger="keyup">
                          <?php $__errorArgs = ['payment_to_admin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>


                <div class="row">
                  <div class="form-group custom_form_group col-md-6 m-auto">
                      <label class="control-label">Payment:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="Amount..." onkeyup="paymentToNormal()" class="form-control" name="total_pay" value="<?php echo e($data->total_pay); ?>" required data-parsley-pattern="[0-9]+$" min="0" data-parsley-length="[1,50]" data-parsley-trigger="keyup" onkeyup="payment()">
                          <?php $__errorArgs = ['total_pay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>

                <div class="row">
                  <div class="form-group custom_form_group col-md-6 m-auto">
                      <label class="control-label">Total Due:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="Amount..." name="due_to_admin_show" class="form-control" value="<?php echo e($data->due_to_admin); ?>" disabled>

                          <input type="hidden" name="due_to_admin" value="<?php echo e($data->due_to_admin); ?>">
                          <?php $__errorArgs = ['due_to_admin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group custom_form_group col-md-6 m-auto">
                      <label class="control-label">Date:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="date" class="form-control" name="date" value="<?php echo e($data->date == NULL ? Carbon\Carbon::now()->format('Y-m-d') : $data->date); ?>" required>
                          <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>
            </div>

              <div class="card-footer card_footer_button text-center">
                  <button type="submit" class="btn btn-primary waves-effect">SAVE & CHANGE</button>
              </div>
          </div>
          
        </form>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
      /* ================ do work ================ */
      $(document).ready(function() {
          $('#customerForm').parsley();
      });
      /* ================ do work ================ */
    </script>
    
    <script type="text/javascript">
      /* ================ do work ================ */
      function officerCommision(){
        var officer_commision = parseFloat( $('input[name="officer_commision"]').val() );
        if(officer_commision >= 0){
          $("#cost").val('');
          $("#cost").val(officer_commision);
          // temporaryField
          $("#temporaryOfficerComision").val('');
          $("#temporaryOfficerComision").val(officer_commision);
        }else{
          $("#cost").val('');
          $("#cost").val(0);
          $("#temporaryOfficerComision").val('');
          $("#temporaryOfficerComision").val(0);
        }
      }

      function agentCommision(){
        var agent_commision = parseFloat( $('#agent_commision').val() );
        var officer_commision = parseFloat( $('input[id="temporaryOfficerComision"]').val() );

        if(agent_commision >= 0){
          var total_costing = (agent_commision + officer_commision);
          $("#cost").val('');
          $("#cost").val(total_costing);
        }else{
          $("#cost").val('');
          $("#cost").val(officer_commision);
        }

      }

      // ================ Full Contact ===========
      function fullContact(){
        var full_contact = parseFloat( $('input[name="full_contact"]').val() );

        var total_pay = parseFloat( $('input[name="total_pay"]').val() );
        var payment_to_admin = parseFloat( $('input[name="payment_to_admin"]').val() );
        var totalPayment = (total_pay + payment_to_admin);

        if(full_contact >= 0){
          var due = (full_contact - totalPayment);
          $('input[name="due_to_admin_show"]').val('');
          $('input[name="due_to_admin"]').val('');
          $('input[name="due_to_admin_show"]').val(due);
          $('input[name="due_to_admin"]').val(due);
        }else{
          $('input[name="due_to_admin_show"]').val('');
          $('input[name="due_to_admin"]').val('');
          $('input[name="due_to_admin_show"]').val(0);
          $('input[name="due_to_admin"]').val(0);
        }

      }
      // ================ Full Contact ===========
      // ================ Payment To Admin ===========
      function paymentToAdmin(){
        var payment_to_admin = parseFloat( $('input[name="payment_to_admin"]').val() );
        var total_pay = parseFloat( $('input[name="total_pay"]').val() );
        var full_contact = parseFloat( $('input[name="full_contact"]').val() );

        if(payment_to_admin >= 0){
          var totalPay = (payment_to_admin + total_pay);
          var due = (full_contact - totalPay);
          $('input[name="due_to_admin_show"]').val('');
          $('input[name="due_to_admin"]').val('');
          $('input[name="due_to_admin_show"]').val(due);
          $('input[name="due_to_admin"]').val(due);
        }else{
          var totalPay = (0 + total_pay);
          var due = (full_contact - totalPay);
          $('input[name="due_to_admin_show"]').val('');
          $('input[name="due_to_admin"]').val('');
          $('input[name="due_to_admin_show"]').val(due);
          $('input[name="due_to_admin"]').val(due);

        }


      }
      function paymentToNormal(){
        var payment_to_admin = parseFloat( $('input[name="payment_to_admin"]').val() );
        var total_pay = parseFloat( $('input[name="total_pay"]').val() );
        var full_contact = parseFloat( $('input[name="full_contact"]').val() );

        if(total_pay >= 0){
          var totalPay = (payment_to_admin + total_pay);
          var due = (full_contact - totalPay);
          $('input[name="due_to_admin_show"]').val('');
          $('input[name="due_to_admin"]').val('');
          $('input[name="due_to_admin_show"]').val(due);
          $('input[name="due_to_admin"]').val(due);
        }else{
          var totalPay = (0 + total_pay);
          var due = (full_contact - totalPay);
          $('input[name="due_to_admin_show"]').val('');
          $('input[name="due_to_admin"]').val('');
          $('input[name="due_to_admin_show"]').val(due);
          $('input[name="due_to_admin"]').val(due);

        }


      }
      /* ================ do work ================ */
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etcvalyc/Creative.etcvaly.com/resources/views/admin/customer_transaction/edit.blade.php ENDPATH**/ ?>