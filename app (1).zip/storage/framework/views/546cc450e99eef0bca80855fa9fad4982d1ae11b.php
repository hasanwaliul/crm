
<?php $__env->startSection('content'); ?>
  
  <div class="row">
      <div class="col-12">
          <div class="page-title-box d-flex align-items-center justify-content-between">
              <h4 class="mb-0 font-size-18">Customer</h4>
              <div class="page-title-right">
                  <ol class="breadcrumb m-0">
                      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                      <li class="breadcrumb-item active">Customer</li>
                  </ol>
              </div>
          </div>
      </div>
  </div>
  
  <div class="row">
      <div class="col-md-2"></div>
      <div class="col-md-8">
          <?php if(Session::has('success_store')): ?>
            <div class="alert alert-success alertsuccess" role="alert">
               <strong>Successfully!</strong> Create New Customer.
            </div>
          <?php endif; ?>

          <?php if(Session::has('error')): ?>
            <div class="alert alert-warning alerterror" role="alert">
               <strong>Opps!</strong> please try again.
            </div>
          <?php endif; ?>
      </div>
      <div class="col-md-2"></div>
  </div>
  
  <div class="row">
    <div class="col-lg-12">
        <form class="form-horizontal" method="post" action="<?php echo e(route('customers.store')); ?>" enctype="multipart/form-data" id="customerCreate">
          <?php echo csrf_field(); ?>
          <div class="card">
            <div class="card-header custom-card-header">
                <div class="row">
                    <div class="col-md-8">
                        <h3 class="card-title card_top_title"><i class="fab fa-gg-circle"></i> Create New Customer</h3>
                    </div>
                    <div class="col-md-4 text-right">
                        <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-md btn-primary waves-effect card_top_button"><i class="fa fa-th"></i> All Customer List </a>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>

            <div class="card-body card_form">
                <div class="row">
                  <div class="form-group custom_form_group col-md-8 m-auto">
                      <label class="control-label">Customer Id No:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="<?php echo e($customerIdNo); ?>" class="form-control" disabled>
                          <input type="hidden" class="form-control" name="customer_id_number" value="<?php echo e($customerIdNo); ?>">
                      </div>
                  </div>
                </div>

                <div class="row">
                  <div class="form-group custom_form_group col-md-6">
                      <label class="control-label">Name:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="Name" class="form-control" name="customer_name" value="<?php echo e(old('customer_name')); ?>" required data-parsley-pattern="[a-zA-Z_ ]+$" data-parsley-length="[3,50]" data-parsley-trigger="keyup">
                          <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-6">
                      <label class="control-label">Father Name:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="Father Name" class="form-control" name="customer_father" value="<?php echo e(old('customer_father')); ?>" required data-parsley-pattern="[a-zA-Z_ ]+$" data-parsley-length="[3,50]" data-parsley-trigger="keyup">
                          <?php $__errorArgs = ['customer_father'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group custom_form_group col-md-6">
                      <label class=" control-label">Phone Number:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="Phone" class="form-control" name="customer_phone" value="<?php echo e(old('customer_phone')); ?>" required data-parsley-pattern="[0-9]+$" data-parsley-length="[11,15]" data-parsley-trigger="keyup">
                          <?php $__errorArgs = ['customer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>

                  <div class="form-group custom_form_group col-md-6">
                      <label class="control-label">Email Address:</label>
                      <div class="">
                          <input type="email" placeholder="Email" class="form-control" name="customer_email" value="<?php echo e(old('customer_email')); ?>" data-parsley-length="[10,50]" data-parsley-trigger="keyup">
                      </div>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group custom_form_group col-md-6">
                      <label class="control-label">Address:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" class="form-control" placeholder="Address Here..." name="customer_address" value="<?php echo e(old('customer_address')); ?>" required data-parsley-pattern="[a-zA-Z_ ]+$" data-parsley-length="[3,50]" data-parsley-trigger="keyup">
                      </div>
                      <?php $__errorArgs = ['customer_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="form-group custom_form_group col-md-6">
                      <label class="control-label">Apply Date:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="date" class="form-control" name="apply_date" value="<?php echo e(Carbon\Carbon::now()->format('Y-m-d')); ?>" required>
                      </div>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-md-6 m-auto mb-3">
                    <label class="col-form-label col_form_label">Refference Officer:</label>
                    <div class="">
                        <select class="form-control search_select" name="employee_id" id="search_select2" required>
                          <option value="">Select Officer</option>
                          <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->employee_id); ?>"><?php echo e($data->employee_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                  </div>
                </div>
                <hr>
                
                <div class="row">
                  <div class="form-group custom_form_group col-md-6 m-auto">
                      <label class="control-label">Place Of Country:<span class="req_star">*</span></label>
                      <div class="">
                          <select class="form-control" name="place_country_id" id="search_select" required>
                            <option value="">Select Country</option>
                            <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($ctry->country_id); ?>" <?php echo e($data->place_country_id == $ctry->country_id ? 'selected' : ''); ?>><?php echo e($ctry->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          <?php $__errorArgs = ['place_country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-6 m-auto">
                      <label class="control-label">Visa Type:<span class="req_star">*</span></label>
                      <div class="">
                          <select class="form-control" name="visa_type_id" id="search_select3" required>
                            <option value="">Select Visa Type</option>
                            <?php $__currentLoopData = $visaType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vsType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($vsType->visa_type_id); ?>" <?php echo e($vsType->visa_type_id == $data->visa_type_id ? 'selected' : ''); ?>><?php echo e($vsType->visa_type_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          <?php $__errorArgs = ['visa_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group custom_form_group col-md-6">
                      <label class=" control-label">Visa Name:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="Visa Name" class="form-control" name="visa_name" value="<?php echo e(old('visa_name')); ?>" required data-parsley-pattern="[a-zA-Z0-9_ ]+$" data-parsley-length="[1,200]" data-parsley-trigger="keyup">
                          <?php $__errorArgs = ['visa_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-6">
                      <label class=" control-label">Visa Remarks:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="Remarks..." class="form-control" name="visa_remarks" value="<?php echo e(old('visa_remarks')); ?>" required data-parsley-pattern="[a-zA-Z0-9_ ]+$" data-parsley-length="[1,220]" data-parsley-trigger="keyup">
                          <?php $__errorArgs = ['visa_remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group custom_form_group col-md-6">
                      <label class=" control-label">From Date:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="date" class="form-control" name="from_date" value="<?php echo e(Carbon\Carbon::now()->format('Y-m-d') ?? old('from_date')); ?>" required>
                          <?php $__errorArgs = ['from_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-6">
                      <label class=" control-label">To Date:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="date" class="form-control" name="to_date" value="<?php echo e(Carbon\Carbon::now()->format('Y-m-d') ?? old('to_date')); ?>" required>
                          <?php $__errorArgs = ['to_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group custom_form_group col-md-4">
                      <label class=" control-label">Visa Number:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="Visa Number" class="form-control" name="visa_number" value="<?php echo e(old('visa_number')); ?>" required data-parsley-pattern="[a-zA-Z0-9_ ]+$" data-parsley-length="[11,15]" data-parsley-trigger="keyup">
                          <?php $__errorArgs = ['visa_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-4">
                      <label class=" control-label">Passport Number:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="Passport Number" class="form-control" name="passport_number" value="<?php echo e(old('passport_number')); ?>" required data-parsley-pattern="[a-zA-Z0-9_ ]+$" data-parsley-length="[11,15]" data-parsley-trigger="keyup">
                          <?php $__errorArgs = ['passport_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-4">
                      <label class=" control-label">Passport Location:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" placeholder="PP Location" class="form-control" name="pp_location" value="<?php echo e(old('pp_location')); ?>" required data-parsley-pattern="[a-zA-Z0-9_ ]+$" data-parsley-length="[1,220]" data-parsley-trigger="keyup">
                          <?php $__errorArgs = ['pp_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group custom_form_group col-md-3">
                      <label class=" control-label">Vecxin:<span class="req_star">*</span></label>
                      <div class="">
                          <select class="form-control" name="vecxin" required>
                            <option value="">Select Yes Or No</option>
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                          </select>

                          <?php $__errorArgs = ['vecxin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-3">
                      <label class=" control-label">PC:<span class="req_star">*</span></label>
                      <div class="">
                          <select class="form-control" name="PC" required>
                              <option value="">Select Yes Or No</option>
                              <option value="1">Yes</option>
                              <option value="0">No</option>
                          </select>
                          <?php $__errorArgs = ['PC'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-3">
                      <label class=" control-label">Medical:<span class="req_star">*</span></label>
                      <div class="">
                          <select class="form-control" name="medical" required>
                              <option value="">Select Yes Or No</option>
                              <option value="1">Yes</option>
                              <option value="0">No</option>
                          </select>
                          <?php $__errorArgs = ['medical'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-3">
                      <label class=" control-label">Medical Date:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="date" name="madical_date" class="form-control" value="<?php echo e(Carbon\Carbon::now()->format('Y-m-d')); ?>" required>
                          <?php $__errorArgs = ['madical_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group custom_form_group col-md-3">
                      <label class=" control-label">Report:<span class="req_star">*</span></label>
                      <div class="">
                          <select class="form-control" name="report" required>
                            <option value="">Select Status</option>
                            <option value="PENDING">PENDING</option>
                            <option value="FIT">FIT</option>
                            <option value="UNFIT">UNFIT</option>
                          </select>

                          <?php $__errorArgs = ['report'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-3">
                      <label class=" control-label">Visa Online:<span class="req_star">*</span></label>
                      <div class="">
                          <select class="form-control" name="visa_online" required>
                              <option value="">Select Yes Or No</option>
                              <option value="1">Yes</option>
                              <option value="0">No</option>
                          </select>
                          <?php $__errorArgs = ['visa_online'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-3">
                      <label class=" control-label">Visa:<span class="req_star">*</span></label>
                      <div class="">
                          <select class="form-control" name="visa" required>
                              <option value="">Select Yes Or No</option>
                              <option value="1">Yes</option>
                              <option value="0">No</option>
                          </select>
                          <?php $__errorArgs = ['visa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-3">
                      <label class=" control-label">Training:<span class="req_star">*</span></label>
                      <div class="">
                          <select class="form-control" name="training" required>
                              <option value="">Select Yes Or No</option>
                              <option value="1">Yes</option>
                              <option value="0">No</option>
                          </select>
                          <?php $__errorArgs = ['training'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group custom_form_group col-md-4">
                      <label class=" control-label">Manpower:<span class="req_star">*</span></label>
                      <div class="">
                          <select class="form-control" name="manpower" required>
                              <option value="">Select Yes Or No</option>
                              <option value="1">Yes</option>
                              <option value="0">No</option>
                          </select>
                          <?php $__errorArgs = ['manpower'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-4">
                      <label class=" control-label">Ticket:<span class="req_star">*</span></label>
                      <div class="">
                          <select class="form-control" name="ticket" required>
                              <option value="">Select Yes Or No</option>
                              <option value="1">Yes</option>
                              <option value="0">No</option>
                          </select>
                          <?php $__errorArgs = ['ticket'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-4">
                      <label class=" control-label">Work Name:<span class="req_star">*</span></label>
                      <div class="">
                          <input type="text" class="form-control" placeholder="Work Name..." name="work" value="<?php echo e(old('work')); ?>" required data-parsley-pattern="[a-zA-Z0-9_ ]+$" data-parsley-length="[1,220]" data-parsley-trigger="keyup">
                          <?php $__errorArgs = ['work'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                </div>
                
                
                <hr>
                
                <div class="row">
                  <div class="form-group custom_form_group col-md-4">
                      <label class=" control-label">Customer Image:<span class="req_star">*</span></label>
                      <div class="row">
                          
                          <div class="col-sm-12">
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <span class="btn btn-default btn-file btnu_browse">
                                        Browse… <input type="file" name="customer_photo" onchange="customer_photoUrl(this)">
                                    </span>
                                </span>
                                <input type="text" class="form-control" readonly>
                            </div>
                            <img src="" id="customer_photoShow" style="margin-top:10px">
                          </div>
                          
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-4">
                      <label class=" control-label">Visa Image:<span class="req_star">*</span></label>
                      <div class="row">
                          
                          <div class="col-sm-12">
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <span class="btn btn-default btn-file btnu_browse">
                                        Browse… <input type="file" name="visa_image" onchange="visa_imageUrl(this)">
                                    </span>
                                </span>
                                <input type="text" class="form-control" readonly>
                            </div>
                            <img src="" id="visa_imageShow" style="margin-top:10px">
                          </div>
                          
                      </div>
                  </div>
                  <div class="form-group custom_form_group col-md-4">
                      <label class=" control-label">Passport Image:<span class="req_star">*</span></label>
                      <div class="row">
                          
                          <div class="col-sm-12">
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <span class="btn btn-default btn-file btnu_browse">
                                        Browse… <input type="file" name="passport_image" onchange="passport_imageUrl(this)">
                                    </span>
                                </span>
                                <input type="text" class="form-control" readonly>
                            </div>
                            <img src="" id="passport_imageShow" style="margin-top:10px">
                          </div>
                          
                      </div>
                  </div>

                </div>
            </div>

              <div class="card-footer card_footer_button text-center">
                  <button type="submit" class="btn btn-primary waves-effect">NEXT</button>
              </div>
          </div>
          
        </form>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('parsley'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
      /* ================ do work ================ */
      $(document).ready(function() {
          $('#customerCreate').parsley();
      });
      /* ================ do work ================ */
    </script>
    
    <script>
      function customer_photoUrl(input){
        if (input.files && input.files[0]) {
          var reader = new FileReader();

          reader.onload = function(e){
              $('#customer_photoShow').attr('src',e.target.result).width(150)
                    .height(150);
          };
          reader.readAsDataURL(input.files[0]);


        }
      }
      function visa_imageUrl(input){
        if (input.files && input.files[0]) {
          var reader = new FileReader();

          reader.onload = function(e){
              $('#visa_imageShow').attr('src',e.target.result).width(150)
                    .height(150);
          };
          reader.readAsDataURL(input.files[0]);


        }
      }
      function passport_imageUrl(input){
        if (input.files && input.files[0]) {
          var reader = new FileReader();

          reader.onload = function(e){
              $('#passport_imageShow').attr('src',e.target.result).width(150)
                    .height(150);
          };
          reader.readAsDataURL(input.files[0]);


        }
      }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etcvalyc/Creative.etcvaly.com/resources/views/admin/customer/create.blade.php ENDPATH**/ ?>