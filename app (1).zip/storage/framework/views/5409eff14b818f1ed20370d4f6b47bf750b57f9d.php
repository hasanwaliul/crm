
<?php $__env->startSection('content'); ?>
  <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header card_header">
                    <div class="row">
                        <div class="col-md-8">
                            <h4 class="card-title card_title"><i class="fab fa-gg-circle"></i> Income Expense Summary</h4>
                        </div>
                        <div class="col-md-4 text-right">
                            <a href="<?php echo e(route('income.create')); ?>" class="btn btn-dark btn-md waves-effect btn-label waves-light card_btn"><i class="fas fa-plus-circle label-icon"></i>Add Income</a>
                            <a href="<?php echo e(route('expense.create')); ?>" class="btn btn-dark btn-md waves-effect btn-label waves-light card_btn"><i class="fas fa-plus-circle label-icon"></i>Add Expense</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row pb-2">
                        <div class="col-md-4">
                          <div class="input-group">
                            <input type="text" class="form-control form_control" id="datepickerFrom" name="from">
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="mdi mdi-calendar"></i><b>From</b></span>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="input-group">
                            <input type="text" class="form-control form_control" id="datepickerTo" name="to">
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="mdi mdi-calendar"></i><b>To</b></span>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-2">
                          <div class="input-group">
                              <input type="button" class="btn btn-dark btn-md waves-effect waves-light card_btn" id="search" value="SEARCH">
                          </div>
                        </div>
                    </div>
                    <table id="inexsummary" class="table table-bordered table-striped table-hover dt-responsive nowrap custom_table">
                        <thead class="thead-dark">
                          <tr>
                            <th>Date</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Debit</th>
                            <th>Credit</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($data->income_date); ?></td>
                              <td><?php echo e($data->income_details); ?></td>
                              <td><?php echo e($data->joinInCat->in_cat_name); ?></td>
                              <td><?php echo e($data->income_amount); ?></td>
                              <td>---</td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php $__currentLoopData = $expense; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($data->expens_date); ?></td>
                              <td><?php echo e($data->expens_details); ?></td>
                              <td><?php echo e($data->joinExCat->exp_cat_name); ?></td>
                              <td>---</td>
                              <td><?php echo e($data->expens_amount); ?></td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th></th>
                                <th></th>
                                <th class="details" style="text-align: right;">Total</th>
                                <th><?php echo e($incomeTotal); ?></th>
                                <th><?php echo e($expenseTotal); ?></th>
                            </tr>
                            <tr>
                                <th class="text-center" colspan="5">
                                    Total Saving:
                                    <?php if($incomeTotal > $expenseTotal): ?>
                                    <span style="color: green;"><?php echo e($incomeTotal-$expenseTotal); ?></span>
                                    <?php else: ?>
                                    <span style="color: red;"><?php echo e($incomeTotal-$expenseTotal); ?></span>
                                    <?php endif; ?>
                                </th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etcvalyc/Creative.etcvaly.com/resources/views/admin/summary/index.blade.php ENDPATH**/ ?>